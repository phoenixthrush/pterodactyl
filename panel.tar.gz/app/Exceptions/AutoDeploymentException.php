<?php

namespace Pterodactyl\Exceptions;

use Exception;

class AutoDeploymentException extends Exception
{
}
