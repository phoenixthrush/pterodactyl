<?php

namespace Pterodactyl\Exceptions\Service\Helper;

use Exception;

class CdnVersionFetchingException extends Exception
{
}
